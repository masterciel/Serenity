﻿using Serenity;
using System.Html;

namespace $ext_safeprojectname$
{
    public static class ScriptInitialization
    {
        static ScriptInitialization()
        {
            Q.Config.RootNamespaces.Add("$ext_safeprojectname$");
        }
    }
}